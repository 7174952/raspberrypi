#!/usr/bin/python3
import time
import rospy
from rospy.exceptions import ROSInterruptException
from sensor_msgs.msg import Range
from std_msgs.msg import String  # 追加
import RPi.GPIO as GPIO

# GPIOピンの設定
trig = 7    # 超音波センサーのトリガーピン
echo = 8    # 超音波センサーのエコーピン

# 超音波距離センサーによる距離計測
def getDistance(TRIG, ECHO, abortTime):
    GPIO.setwarnings(False)  # GPIOの警告を非表示に設定
    GPIO.setmode(GPIO.BOARD)  # GPIOピンの番号付けをBOARDに設定
    GPIO.setup(TRIG, GPIO.OUT)  # トリガーピンを出力に設定
    GPIO.setup(ECHO, GPIO.IN)   # エコーピンを入力に設定
    GPIO.output(TRIG, GPIO.LOW)  # トリガーピンをLOWに設定
    time.sleep(0.01)  # 10ms待機して安定させる

    GPIO.output(TRIG, GPIO.HIGH)  # トリガーピンをHIGHに設定して超音波パルスを送信
    time.sleep(0.00001)  # 10μs待機してパルスを送信
    GPIO.output(TRIG, GPIO.LOW)  # トリガーピンをLOWに戻す

    startTime = time.time()  # エコーパルスが戻ってくるまでの時間計測開始
    while GPIO.input(ECHO) == 0:  # エコーピンがLOWの間ループ
        signaloff = time.time()  # LOWの開始時間を記録
        if ((signaloff - startTime) > abortTime):  # 指定時間経過したらエラーを返す
            distance = -1
            return distance

    while GPIO.input(ECHO) == 1:  # エコーピンがHIGHの間ループ
        signalon = time.time()  # HIGHの開始時間を記録

    timepassed = signalon - signaloff  # エコーパルスの往復時間を計算
    # 距離[cm] = 時間[s] * 音速(34000)[cm/s]/2
    distance = timepassed * 17000 / 100 # 距離計算
    return distance  # 距離を返す

class SonarSensor:
    def __init__(self):
        rospy.init_node('rober', anonymous=True)  # ノードの初期化
        rospy.on_shutdown(self.shutdown)  # ノードの終了時にshutdownメソッドを呼び出す
        self.pub = rospy.Publisher('scan', Range, queue_size=10)  # パブリッシャーの設定
        self.status_pub = rospy.Publisher('status', String, queue_size=10)  # ステータス用のパブリッシャーを設定
        rospy.Timer(rospy.Duration(1.0), self.timer_callback)  # 1秒ごとにtimer_callbackメソッドを呼び出す

        # 距離の閾値とカウントに関する変数
        self.distance_threshold = 0.05
        self.zero_count = 0

    def timer_callback(self, data):
        # 超音波センサーから距離を取得
        dist = getDistance(trig, echo, 0.3)

        # 距離をログとして表示
        rospy.loginfo("distance: %f", dist)

        # Rangeメッセージを作成して距離データをセット
        sensor_data = Range()
        sensor_data.range = dist

        # Rangeメッセージを 'scan' トピックにパブリッシュ
        self.pub.publish(sensor_data)

        # 距離が閾値以下の場合は"RUN"、それ以外は"STOP"を出力
        if dist <= self.distance_threshold:
            self.zero_count = 0
            rospy.loginfo("RUN")
            # 'status' フィールドに文字列"RUN"をセットしてパブリッシュ
            self.publish_status("RUN")
        else:
            self.zero_count += 1
            if self.zero_count >= 5:
                rospy.loginfo("STOP")
                # 'status' フィールドに文字列"STOP"をセットしてパブリッシュ
                self.publish_status("STOP")
            else:
                rospy.loginfo("RUN")
                # 'status' フィールドに文字列"RUN"をセットしてパブリッシュ
                self.publish_status("RUN")

    def publish_status(self, status):
        # Stringメッセージを作成してステータスをセット
        status_msg = String()
        status_msg.data = status
        # Stringメッセージを 'status' トピックにパブリッシュ
        self.status_pub.publish(status_msg)

    def shutdown(self):
        rospy.sleep(1)  # シャットダウン前に1秒待機
        rospy.loginfo("Shutdown")  # シャットダウンメッセージをログとして表示

        # ピン設定解除
        GPIO.cleanup()

if __name__ == '__main__':
    try:
        SonarSensor()  # SonarSensorクラスのインスタンスを生成してノードを開始
        rospy.spin()  # ノードが終了するまで実行を継続
    except ROSInterruptException:
        # ピン設定解除
        GPIO.cleanup()
        pass

