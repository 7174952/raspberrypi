#!/usr/bin/python3
import os
import time
import rospy
from rospy.exceptions import ROSInterruptException
from sensor_msgs.msg import Range
import RPi.GPIO as GPIO

# GPIOピンの設定
trig_pin = 14
echo_pin = 15

# GPIOのセットアップ
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(trig_pin, GPIO.OUT)
GPIO.setup(echo_pin, GPIO.IN)

# ROSのノードとして初期化
rospy.init_node('rober', anonymous=True)

# パブリッシャーの準備
pub = rospy.Publisher('scan', Range, queue_size=10)

# 距離を計測する関数
def calc_distance():
    # TRIGピンを0.3秒だけLOW
    GPIO.output(trig_pin, GPIO.LOW)
    time.sleep(0.3)
    # TRIGピンを0.00001秒だけHIGH
    GPIO.output(trig_pin, True)
    time.sleep(0.00001)
    GPIO.output(trig_pin, False)

    # ECHO_PINがHIGHの時間を計測
    start_time = time.time()
    end_time = time.time()
    while GPIO.input(echo_pin) == 0:
        start_time = time.time()
    while GPIO.input(echo_pin) == 1:
        end_time = time.time()

    # 距離(cm) = 音速(34000 cm/s) * 時間 / 2
    distance = (end_time - start_time) * 34000 / 2
    return distance

# 出力ディレクトリの作成（ソースコードと同じディレクトリ）
output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'output_faces')
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 出力ファイルのパス
output_file_path = os.path.join(output_dir, 'distance_status.txt')

# 距離の閾値
distance_threshold = 40

# 距離が閾値を超えている時間をカウントするための変数
zero_count = 0

# 距離が閾値以下である時間の合計
total_time_below_threshold = 0

# 距離が閾値以下であるフレームの数
frame_count_below_threshold = 0

# 距離が閾値を超えている時間の合計
total_time_above_threshold = 0

# 距離が閾値を超えているフレームの数
frame_count_above_threshold = 0

try:
    start_time = time.time()
    while True:
        # 距離を計測
        distance = calc_distance()

        # 距離が閾値以下の場合
        if distance <= distance_threshold:
            frame_count_below_threshold += 1
            total_time_below_threshold += time.time() - start_time
            total_time_above_threshold = 0
            frame_count_above_threshold = 0
        # 距離が閾値を超えた場合
        else:
            frame_count_above_threshold += 1
            total_time_above_threshold += time.time() - start_time
            total_time_below_threshold = 0
            frame_count_below_threshold = 0

        # 距離が閾値を超えている時間が1秒以上であれば"STOP"を出力
        if total_time_above_threshold >= 1.0:
            with open(output_file_path, 'w') as output_file:
                output_file.write("STOP\n")
            print("STOP")
            zero_count = 0
        # 距離が閾値以下である時間が1秒以上であれば"RUN"を出力
        elif total_time_below_threshold >= 1.0:
            with open(output_file_path, 'w') as output_file:
                output_file.write("RUN\n")
            print("RUN")
            zero_count = 0
        # 距離が閾値を超えている時間が1秒未満、かつ距離が閾値以下である時間が1秒未満の場合
        else:
            zero_count += 1
            if zero_count >= 5:
                with open(output_file_path, 'w') as output_file:
                    output_file.write("STOP\n")
                print("STOP")
            else:
                with open(output_file_path, 'w') as output_file:
                    output_file.write("RUN\n")
                print("RUN")

        time.sleep(1)  # 1秒待機

except ROSInterruptException:
    # ピン設定解除
    GPIO.cleanup()

finally:
    GPIO.cleanup()  # ピン設定解除

