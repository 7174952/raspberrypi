#!/usr/bin/python3
import time
import rospy
from rospy.exceptions import ROSInterruptException
from sensor_msgs.msg import Range
import RPi.GPIO as GPIO

trigCenter = 15
echoCenter = 16
trigLeft = 19
echoLeft = 18
trigRight = 7
echoRight = 8

# 超音波距離センサーによる距離計測
def getDistance(TRIG, ECHO, abortTime):
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(TRIG, GPIO.OUT)
    GPIO.setup(ECHO, GPIO.IN)
    GPIO.output(TRIG, GPIO.LOW)
    time.sleep(0.01)

    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    startTime = time.time()
    while GPIO.input(ECHO) == 0:
        signaloff = time.time()

        if ((signaloff - startTime) > abortTime):
            distance = -1
            return distance

    while GPIO.input(ECHO) == 1:
        signalon = time.time()

    timepassed = signalon - signaloff
    distance = timepassed * 17000 /100

    return distance

    GPIO.cleanup()

class SonarSensor:
    def __init__(self):
        rospy.init_node('rober', anonymous=True)
        rospy.on_shutdown(self.shutdown)
        self.pub = rospy.Publisher('scan', Range, queue_size=10)
        rospy.Timer(rospy.Duration(1.0), self.timer_callback)

    def timer_callback(self, data):
        distCenter = getDistance(trigCenter, echoCenter, 0.1)
        distLeft = getDistance(trigLeft, echoLeft, 0.1)
        distRight = getDistance(trigRight, echoRight, 0.3)

        rospy.loginfo("Center distance: %f", distCenter)
        rospy.loginfo("Left distance: %f", distLeft)
        rospy.loginfo("Right distance: %f", distRight)

        # ここから先は必要に応じて追加の処理を行います

    def shutdown(self):
        rospy.sleep(1)
        rospy.loginfo("Shutdown")

if __name__ == '__main__':
    try:
        SonarSensor()
        rospy.spin()
    except ROSInterruptException:
        # ピン設定解除
        GPIO.cleanup()
        pass

