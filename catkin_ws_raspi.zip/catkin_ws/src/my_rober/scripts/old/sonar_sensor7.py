#!/usr/bin/python3
import os
import time
import rospy
from sensor_msgs.msg import Range
import RPi.GPIO as GPIO

# GPIOピンの設定
trig_pin = 14
echo_pin = 15

# GPIOのセットアップ
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(trig_pin, GPIO.OUT)
GPIO.setup(echo_pin, GPIO.IN)

# ROSのノードとして初期化
rospy.init_node('ultrasonic_sensor', anonymous=True)

# パブリッシャーの準備
pub = rospy.Publisher('scan', Range, queue_size=10)

# 距離を計測する関数
def calc_distance():
    # TRIGピンを0.3秒だけLOW
    GPIO.output(trig_pin, GPIO.LOW)
    time.sleep(0.3)
    # TRIGピンを0.00001秒だけHIGH
    GPIO.output(trig_pin, True)
    time.sleep(0.00001)
    GPIO.output(trig_pin, False)

    # ECHO_PINがHIGHの時間を計測
    start_time = time.time()
    end_time = time.time()
    while GPIO.input(echo_pin) == 0:
        start_time = time.time()
    while GPIO.input(echo_pin) == 1:
        end_time = time.time()

    # 距離(cm) = 音速(34000 cm/s) * 時間 / 2
    distance = (end_time - start_time) * 34000 / 2
    return distance

try:
    while not rospy.is_shutdown():
        # 距離を計測
        distance = calc_distance()

        # Rangeメッセージを作成
        range_msg = Range()
        range_msg.header.stamp = rospy.Time.now()
        range_msg.header.frame_id = "ultrasonic_sensor"
        range_msg.radiation_type = Range.ULTRASOUND
        range_msg.field_of_view = 0.1
        range_msg.min_range = 0.02
        range_msg.max_range = 4.0
        range_msg.range = distance / 100.0  # メートルに変換

        # 距離データをパブリッシュ
        pub.publish(range_msg)

        time.sleep(0.1)  # 0.1秒待機

except rospy.ROSInterruptException:
    pass

finally:
    GPIO.cleanup()  # ピン設定解除

