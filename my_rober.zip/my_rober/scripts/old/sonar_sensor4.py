#!/usr/bin/python3
import time
import rospy
from rospy.exceptions import ROSInterruptException
from sensor_msgs.msg import Range
import RPi.GPIO as GPIO
import sys

trig_pin = 14
echo_pin = 15

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(trig_pin, GPIO.OUT)
GPIO.setup(echo_pin, GPIO.IN)


class SonarSensor:
    def __init__(self):
        rospy.init_node('rober', anonymous=True)
        rospy.on_shutdown(self.shutdown)
        self.pub = rospy.Publisher('scan', Range, queue_size=10)
        self.last_stop_time = None
        self.distance_values = []

    def pulse_in(self, PIN, start=1, end=0):
        if start == 0:
            end = 1
        t_start = time.time()
        t_end = time.time()
        while GPIO.input(PIN) == end:
            t_start = time.time()
            if t_start - t_end > 1:  # タイムアウト処理
                break

        while GPIO.input(PIN) == start:
            t_end = time.time()
            if t_end - t_start > 1:  # タイムアウト処理
                break
        return t_end - t_start

    def calc_distance(self):
        GPIO.output(trig_pin, GPIO.LOW)
        time.sleep(0.05)
        GPIO.output(trig_pin, True)
        time.sleep(0.00001)
        GPIO.output(trig_pin, False)
        t = self.pulse_in(echo_pin)
        v = 34000
        distance = v * t / 2
        return distance

    def timer_callback(self, data):
        distance = self.calc_distance()
        self.distance_values.append(distance)

        if len(self.distance_values) > 0:
            average_distance = sum(self.distance_values) / len(self.distance_values)

            if average_distance < 40:
                rospy.loginfo("RUN")
                range_msg = Range()
                range_msg.range = average_distance
                self.pub.publish(range_msg)
                self.last_stop_time = None
            else:
                if self.last_stop_time is None:
                    self.last_stop_time = time.time()
                elif time.time() - self.last_stop_time > 3:
                    rospy.loginfo("STOP")
                    range_msg = Range()
                    range_msg.range = 0
                    self.pub.publish(range_msg)

        self.distance_values = []  # 距離データのリセット

    def shutdown(self):
        rospy.sleep(1)
        rospy.loginfo("Shutdown")


if __name__ == '__main__':
    try:
        sonar = SonarSensor()
        rospy.Timer(rospy.Duration(1.0), sonar.timer_callback)

        while not rospy.is_shutdown():
            # ESCキーが押されるまで待機
            if sys.stdin.read(1) == chr(27):
                break

    except ROSInterruptException:
        GPIO.cleanup()
        pass

