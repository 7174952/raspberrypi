#!/usr/bin/python3

import RPi.GPIO as GPIO
import time
import rospy
from std_msgs.msg import Float32

TRIG = 16
ECHO = 18

def setup():
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(TRIG, GPIO.OUT)
    GPIO.setup(ECHO, GPIO.IN)

def distance():
    GPIO.output(TRIG, 0)
    time.sleep(0.000002)

    GPIO.output(TRIG, 1)
    time.sleep(0.00001)
    GPIO.output(TRIG, 0)

    while GPIO.input(ECHO) == 0:
        a = 0
    time1 = time.time()
    while GPIO.input(ECHO) == 1:
        a = 1
    time2 = time.time()

    during = time2 - time1
    return during * 340 / 2 * 100

def loop():
    pub = rospy.Publisher('distance', Float32, queue_size=10)
    rospy.init_node('distance_sensor_node', anonymous=True)
    rate = rospy.Rate(10)  # 10hz
    while not rospy.is_shutdown():
        dis = distance()
        rospy.loginfo('Distance: %.2f' % dis)
        pub.publish(dis)
        rate.sleep()

def destroy():
    GPIO.cleanup()

if __name__ == "__main__":
    setup()
    try:
        loop()
    except rospy.ROSInterruptException:
        destroy()


